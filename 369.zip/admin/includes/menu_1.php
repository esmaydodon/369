<?php
echo "  <div id='menu'>
    <ul>
      <li><a href='destruir.php' class='current'>SALIR</a></li>
      <li><a href='personal.php'>PERSONAL</a></li>
      <li><a href='ubigeo.php'>PROVINCIAS / DISTRITOS</a></li>
      <li><a href='AsignarUsuarioUbigeo.php'>DISTRITOS ASIGNADOS</a></li>
      <li><a href='InformePrCt.php'>INFORMES PR / CT</a></li>
      <li><a href='panel.php'>INICIO</a></li>
    </ul>
  </div>";
?>