<?php
  echo "<div id='menu'>
         <ul>
         <li><a href='personal_panel.php' class='current'>PERFIL</a></li>
         <li><a href='directorio.php' class='current'>DIRECTORIO</a></li>
         <li><a href='formato1.php'>FORMATO 1</a></li>
         <li><a href='formato2.php'>FORMATO 2</a></li>
         <li><a href='formato3.php'>FORMATO 3</a></li>
        <li><a href='destruir.php' class='current'>SALIR</a></li> 
</ul>
        </div>";
  ?>
