<?php
echo "<div style ='float left;'id='menu'>".
 date("Y-m-d H:i:s")."
    <ul>
      <li><a href='personal_panel_secretaria.php'>REGISTRAR PAPELETA</a></li>
	  <li><a href='documentos_enlace.php'>DOCUMENTOS</a></li>
	  <li><a href='REPORTE.php'>.</a></li>
       <li><a href='destruir.php' class='current'>SALIR</a></li>
    </ul>
  </div>";
?>